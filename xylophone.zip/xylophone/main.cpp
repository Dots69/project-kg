// xylophone — a 3D children's xylophone (10 coloured metal plates on a pine frame)
// you can play with the PC keyboard or the mouse.
// C++17 · OpenGL 2.1 + GLSL 1.20 (shader functions loaded through GLFW, no extra loader)
// GLFW for the window and input · miniaudio for sound.
//
// Graphics techniques:
//   * procedural geometry (plates, frame, screws, mallets) built in code
//   * procedural wood texture in the fragment shader (3D value noise + fBm, no image files)
//   * physically-motivated shading: Blinn-Phong with roughness, Fresnel (Schlick), fake studio
//     environment reflections, ACES tone mapping, gamma correction
//   * shadow mapping (depth texture rendered from the light, 3x3 PCF)
//   * vertex-shader deformation: a struck plate bends in the first mode shape of a free-free beam
//   * ray picking: clicking on a plate casts a ray from the camera and intersects the plates' boxes
// Sound: modal synthesis (sum of exponentially decaying sine partials in the ratios of a uniform
// metal bar: 1 : 2.756 : 5.404 : 8.933) plus a short filtered noise "click" from the mallet.
//
// Keys (10 plates, C6 .. E7, white notes only):
//   1 2 3 4 5 6 7 8 9 0   or   A S D F G H J K L ;
//   hold Shift = soft stroke
//   Left click on a plate = strike it · drag empty space = orbit · scroll = zoom
//   F1 = shadows on/off · F2 = plate bending on/off · Esc = quit

#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"
#include <GLFW/glfw3.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#ifdef _WIN32
#define GLCALL __stdcall
#else
#define GLCALL
#endif

#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_VERTEX_SHADER 0x8B31
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#endif
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#endif
#ifndef GL_TEXTURE0
#define GL_TEXTURE0 0x84C0
#define GL_TEXTURE1 0x84C1
#endif
#ifndef GL_DEPTH_COMPONENT24
#define GL_DEPTH_COMPONENT24 0x81A6
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE 0x809D
#endif

// ---------------------------------------------------------------- OpenGL 2.0+ functions
// Windows only exports OpenGL 1.1, so everything newer is fetched at runtime via GLFW.
#define GL_REQUIRED                                                                   \
    F(GLuint, CreateShader, (GLenum))                                                 \
    F(void, ShaderSource, (GLuint, GLsizei, const char* const*, const GLint*))        \
    F(void, CompileShader, (GLuint))                                                  \
    F(void, GetShaderiv, (GLuint, GLenum, GLint*))                                    \
    F(void, GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, char*))                     \
    F(GLuint, CreateProgram, (void))                                                  \
    F(void, AttachShader, (GLuint, GLuint))                                           \
    F(void, LinkProgram, (GLuint))                                                    \
    F(void, GetProgramiv, (GLuint, GLenum, GLint*))                                   \
    F(void, GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, char*))                    \
    F(void, UseProgram, (GLuint))                                                     \
    F(GLint, GetUniformLocation, (GLuint, const char*))                               \
    F(void, Uniform1i, (GLint, GLint))                                                \
    F(void, Uniform1f, (GLint, GLfloat))                                              \
    F(void, Uniform3f, (GLint, GLfloat, GLfloat, GLfloat))                            \
    F(void, UniformMatrix4fv, (GLint, GLsizei, GLboolean, const GLfloat*))            \
    F(void, ActiveTexture, (GLenum))
#define GL_OPTIONAL                                                                   \
    F(void, GenFramebuffers, (GLsizei, GLuint*))                                      \
    F(void, BindFramebuffer, (GLenum, GLuint))                                        \
    F(void, FramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint))            \
    F(GLenum, CheckFramebufferStatus, (GLenum))

#define F(ret, name, args) typedef ret(GLCALL* PFN_##name) args; static PFN_##name p##name = nullptr;
GL_REQUIRED
GL_OPTIONAL
#undef F

static bool loadGL(bool& haveFbo) {
    bool ok = true;
#define F(ret, name, args) \
    p##name = (PFN_##name)glfwGetProcAddress("gl" #name); if (!p##name) ok = false;
    GL_REQUIRED
#undef F
    haveFbo = true;
#define F(ret, name, args)                                                       \
    p##name = (PFN_##name)glfwGetProcAddress("gl" #name);                        \
    if (!p##name) p##name = (PFN_##name)glfwGetProcAddress("gl" #name "EXT");    \
    if (!p##name) haveFbo = false;
    GL_OPTIONAL
#undef F
    return ok;
}

// ---------------------------------------------------------------- math
static const float PI = 3.14159265358979f;
struct V3 { float x, y, z; };
static V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static V3 operator*(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
static float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static float length(V3 a) { return std::sqrt(dot(a, a)); }
static V3 norm(V3 a) { float l = length(a); return l > 1e-8f ? a * (1.0f / l) : a; }

struct M4 { float m[16]; };  // column-major, like OpenGL
static M4 ident() { M4 r{}; r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1; return r; }
static M4 mul(const M4& a, const M4& b) {
    M4 r{};
    for (int c = 0; c < 4; c++)
        for (int row = 0; row < 4; row++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + row] * b.m[c * 4 + k];
            r.m[c * 4 + row] = s;
        }
    return r;
}
// columns X, Y, Z (already scaled) and origin O
static M4 basis(V3 X, V3 Y, V3 Z, V3 O) {
    M4 r = ident();
    r.m[0] = X.x; r.m[1] = X.y; r.m[2] = X.z;
    r.m[4] = Y.x; r.m[5] = Y.y; r.m[6] = Y.z;
    r.m[8] = Z.x; r.m[9] = Z.y; r.m[10] = Z.z;
    r.m[12] = O.x; r.m[13] = O.y; r.m[14] = O.z;
    return r;
}
static M4 translate(V3 t) { return basis({1, 0, 0}, {0, 1, 0}, {0, 0, 1}, t); }
static M4 trs(V3 t, V3 s) { return basis({s.x, 0, 0}, {0, s.y, 0}, {0, 0, s.z}, t); }
static M4 perspective(float fovy, float aspect, float n, float f) {
    M4 r{};
    float t = 1.0f / std::tan(fovy * 0.5f);
    r.m[0] = t / aspect; r.m[5] = t;
    r.m[10] = (f + n) / (n - f); r.m[11] = -1;
    r.m[14] = 2 * f * n / (n - f);
    return r;
}
static M4 ortho(float l, float rr, float b, float t, float n, float f) {
    M4 r = ident();
    r.m[0] = 2 / (rr - l); r.m[5] = 2 / (t - b); r.m[10] = -2 / (f - n);
    r.m[12] = -(rr + l) / (rr - l); r.m[13] = -(t + b) / (t - b); r.m[14] = -(f + n) / (f - n);
    return r;
}
static M4 lookAt(V3 eye, V3 at, V3 up) {
    V3 f = norm(at - eye), s = norm(cross(f, up)), u = cross(s, f);
    M4 r = ident();
    r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
    r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
    r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
    r.m[12] = -dot(s, eye); r.m[13] = -dot(u, eye); r.m[14] = dot(f, eye);
    return r;
}

// ---------------------------------------------------------------- meshes
// Interleaved position + normal, drawn as plain triangles from client memory (OpenGL 1.1 arrays).
struct Mesh {
    std::vector<float> v;
    void vert(V3 p, V3 n) { v.insert(v.end(), {p.x, p.y, p.z, n.x, n.y, n.z}); }
    void draw() const {
        glVertexPointer(3, GL_FLOAT, 24, v.data());
        glNormalPointer(GL_FLOAT, 24, v.data() + 3);
        glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(v.size() / 6));
    }
};

// Rectangle o .. o+u+v split into nu x nv quads.
static void addGrid(Mesh& m, V3 o, V3 u, V3 v, int nu, int nv, V3 n) {
    for (int i = 0; i < nu; i++)
        for (int j = 0; j < nv; j++) {
            V3 p00 = o + u * (float(i) / nu) + v * (float(j) / nv);
            V3 p10 = o + u * (float(i + 1) / nu) + v * (float(j) / nv);
            V3 p11 = o + u * (float(i + 1) / nu) + v * (float(j + 1) / nv);
            V3 p01 = o + u * (float(i) / nu) + v * (float(j + 1) / nv);
            m.vert(p00, n); m.vert(p10, n); m.vert(p11, n);
            m.vert(p00, n); m.vert(p11, n); m.vert(p01, n);
        }
}

// Box centred at the origin; the long faces are split into nz pieces along z so it can bend.
static Mesh makeBox(float hx, float hy, float hz, int nz) {
    Mesh m;
    addGrid(m, {-hx, hy, -hz}, {2 * hx, 0, 0}, {0, 0, 2 * hz}, 1, nz, {0, 1, 0});
    addGrid(m, {-hx, -hy, -hz}, {2 * hx, 0, 0}, {0, 0, 2 * hz}, 1, nz, {0, -1, 0});
    addGrid(m, {hx, -hy, -hz}, {0, 2 * hy, 0}, {0, 0, 2 * hz}, 1, nz, {1, 0, 0});
    addGrid(m, {-hx, -hy, -hz}, {0, 2 * hy, 0}, {0, 0, 2 * hz}, 1, nz, {-1, 0, 0});
    addGrid(m, {-hx, -hy, hz}, {2 * hx, 0, 0}, {0, 2 * hy, 0}, 1, 1, {0, 0, 1});
    addGrid(m, {-hx, -hy, -hz}, {2 * hx, 0, 0}, {0, 2 * hy, 0}, 1, 1, {0, 0, -1});
    return m;
}

// Cylinder of radius 1 along y from 0 to 1.
static Mesh makeCylinder(int segs, bool bottomCap, bool topCap) {
    Mesh m;
    for (int i = 0; i < segs; i++) {
        float a0 = 2 * PI * i / segs, a1 = 2 * PI * (i + 1) / segs;
        V3 n0 = {std::cos(a0), 0, std::sin(a0)}, n1 = {std::cos(a1), 0, std::sin(a1)};
        V3 b0 = n0, b1 = n1, t0 = n0 + V3{0, 1, 0}, t1 = n1 + V3{0, 1, 0};
        m.vert(b0, n0); m.vert(b1, n1); m.vert(t1, n1);
        m.vert(b0, n0); m.vert(t1, n1); m.vert(t0, n0);
        if (bottomCap) { m.vert({0, 0, 0}, {0, -1, 0}); m.vert(b1, {0, -1, 0}); m.vert(b0, {0, -1, 0}); }
        if (topCap) { m.vert({0, 1, 0}, {0, 1, 0}); m.vert(t0, {0, 1, 0}); m.vert(t1, {0, 1, 0}); }
    }
    return m;
}

static Mesh makeSphere(int slices, int stacks) {
    Mesh m;
    auto P = [&](int i, int j) {
        float th = PI * j / stacks, ph = 2 * PI * i / slices;
        return V3{std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph)};
    };
    for (int i = 0; i < slices; i++)
        for (int j = 0; j < stacks; j++) {
            V3 a = P(i, j), b = P(i + 1, j), c = P(i + 1, j + 1), d = P(i, j + 1);
            m.vert(a, a); m.vert(b, b); m.vert(c, c);
            m.vert(a, a); m.vert(c, c); m.vert(d, d);
        }
    return m;
}

// ---------------------------------------------------------------- shaders
static const char* VS_SRC = R"(
#version 120
uniform mat4 uModel;
uniform mat4 uVP;
uniform mat4 uLightVP;
uniform float uBend;     // displacement amplitude of a vibrating bar
uniform float uBarLen;   // > 0 only for bars: length along local z
varying vec3 vWorld;
varying vec3 vNormal;
varying vec3 vLocal;
varying vec4 vLightPos;

float ch(float x) { return 0.5 * (exp(x) + exp(-x)); }
float sh(float x) { return 0.5 * (exp(x) - exp(-x)); }
// First bending mode of a free-free (Euler-Bernoulli) beam, s in [0,1].
// Nodes at s = 0.224 and 0.776 - exactly where the bar rests on the frame.
float modeShape(float s) {
    float b = 4.7300408 * s;
    return 0.5 * (ch(b) + cos(b) - 0.9825022 * (sh(b) + sin(b)));
}

void main() {
    vec3 p = gl_Vertex.xyz;
    vLocal = p;
    if (uBarLen > 0.0) p.y += uBend * modeShape(clamp(p.z / uBarLen + 0.5, 0.0, 1.0));
    vec4 w = uModel * vec4(p, 1.0);
    vWorld = w.xyz;
    vNormal = mat3(uModel) * gl_Normal;
    vLightPos = uLightVP * w;
    gl_Position = uVP * w;
}
)";

static const char* DEPTH_FS_SRC = R"(
#version 120
void main() { gl_FragColor = vec4(1.0); }
)";

static const char* FS_SRC = R"(
#version 120
uniform int uMat;          // 0 bar wood, 1 metal, 2 rubber, 3 frame wood, 4 floor, 5 unlit, 6 painted metal
uniform vec3 uColor;
uniform vec3 uCam;
uniform vec3 uLightDir;    // towards the key light
uniform sampler2D uShadow;
uniform float uShadowOn;
uniform float uGlow;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec3 vLocal;
varying vec4 vLightPos;

// ---- 3D value noise and fractal Brownian motion (procedural texturing)
float hash(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
    vec3 i = floor(x), f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x),
                   mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
                   mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p) {
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) { s += a * noise(p); p *= 2.03; a *= 0.5; }
    return s;
}

// Wood: growth rings across the board, stretched along the grain direction (local axis g).
vec3 wood(vec3 base, vec3 p, float ringFreq) {
    float warp = fbm(p * vec3(25.0, 25.0, 25.0)) * 2.5;
    float g = fract((p.x * 0.7 + p.y) * ringFreq + warp);
    float ring = smoothstep(0.0, 0.25, g) * smoothstep(1.0, 0.55, g);
    float fibre = noise(p * vec3(700.0, 700.0, 15.0));
    float blot = fbm(p * 6.0);
    vec3 dark = base * 0.45, light = base * 1.2;
    return mix(dark, light, ring * 0.65 + fibre * 0.2 + blot * 0.25);
}

// Fake photo-studio surroundings, used for reflections.
vec3 studio(vec3 r) {
    float t = clamp(r.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 c = mix(vec3(0.03, 0.028, 0.025), vec3(0.22, 0.23, 0.26), t);
    float box1 = smoothstep(0.86, 0.93, dot(r, normalize(vec3(-0.5, 0.8, 0.5))));
    float box2 = smoothstep(0.92, 0.97, dot(r, normalize(vec3(0.75, 0.45, 0.2))));
    float strip = smoothstep(0.96, 0.99, 1.0 - abs(r.x)) * step(0.2, r.y);
    return c + vec3(2.4, 2.3, 2.1) * box1 + vec3(1.0, 1.1, 1.3) * box2 + vec3(0.6) * strip;
}

float shadowFactor(vec3 N, vec3 L) {
    if (uShadowOn < 0.5) return 1.0;
    vec3 p = vLightPos.xyz / vLightPos.w * 0.5 + 0.5;
    if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0 || p.z > 1.0) return 1.0;
    float bias = 0.0004 + 0.0012 * (1.0 - max(dot(N, L), 0.0));
    float s = 0.0, texel = 1.0 / 2048.0;
    for (int x = -1; x <= 1; x++)
        for (int y = -1; y <= 1; y++) {
            float d = texture2D(uShadow, p.xy + vec2(x, y) * texel * 1.5).r;
            s += (p.z - bias > d) ? 0.0 : 1.0;
        }
    return s / 9.0;
}

vec3 aces(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }

void main() {
    vec3 base = pow(uColor, vec3(2.2));
    if (uMat == 5) { gl_FragColor = vec4(base, 1.0); return; }

    vec3 N = normalize(vNormal);
    vec3 V = normalize(uCam - vWorld);
    if (dot(N, V) < 0.0) N = -N;
    vec3 L = normalize(uLightDir);

    vec3 albedo = base;
    float rough = 0.5, metal = 0.0, f0 = 0.04;
    if (uMat == 0) {                              // varnished rosewood bar, grain along z
        albedo = wood(base, vLocal * vec3(1.0, 1.0, 0.08), 70.0);
        rough = 0.3;
    } else if (uMat == 1) {                       // polished metal tube
        metal = 1.0; rough = 0.22;
    } else if (uMat == 2) {                       // hard rubber mallet head
        rough = 0.45;
    } else if (uMat == 6) {                       // enamel-painted metal plate
        float speck = noise(vLocal * 900.0) * 0.06; // faint orange-peel of the paint
        albedo = base * (0.97 + speck);
        rough = 0.24; f0 = 0.05;
    } else if (uMat == 3) {                       // frame / mallet stick wood
        albedo = wood(base, vLocal.zyx * vec3(1.0, 1.0, 0.1) + vWorld * 0.3, 18.0);
        rough = 0.5;
    } else if (uMat == 4) {                       // stage floor planks
        float plank = floor(vWorld.z * 7.0);
        float tone = 0.75 + 0.5 * hash(vec3(plank, 3.0, 1.0));
        albedo = wood(base * tone, vec3(vWorld.z * 7.0, 0.0, vWorld.x * 0.4 + plank), 4.0);
        float seam = smoothstep(0.0, 0.03, fract(vWorld.z * 7.0));
        albedo *= mix(0.4, 1.0, seam);
        rough = 0.65;
    }

    float sh = shadowFactor(N, L);
    vec3 H = normalize(L + V);
    float NdL = max(dot(N, L), 0.0), NdH = max(dot(N, H), 0.0), NdV = max(dot(N, V), 0.0);
    float shin = 2.0 / (rough * rough * rough * rough) - 2.0;     // roughness -> Blinn-Phong exponent
    float specD = pow(NdH, shin) * (shin + 8.0) / 25.13274;       // energy-normalised
    vec3 F0 = mix(vec3(f0), albedo, metal);
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - NdV, 5.0);              // Schlick Fresnel
    vec3 diffuse = (1.0 - metal) * albedo;

    vec3 keyCol = vec3(3.2, 3.0, 2.7);
    vec3 col = (diffuse * (1.0 - F) / 3.14159 + F * specD) * keyCol * NdL * sh;

    vec3 L2 = normalize(vec3(0.8, 0.35, -0.6));                   // cool rim/fill light, no shadow
    col += diffuse / 3.14159 * max(dot(N, L2), 0.0) * vec3(0.6, 0.7, 0.9);

    vec3 amb = mix(vec3(0.04, 0.035, 0.03), vec3(0.16, 0.17, 0.2), N.y * 0.5 + 0.5);
    col += diffuse * amb * mix(0.55, 1.0, sh);

    vec3 R = reflect(-V, N);
    vec3 env = mix(studio(R), vec3(0.12), clamp(rough * 1.2, 0.0, 1.0));
    col += F * env * (metal > 0.5 ? 1.0 : 0.6) * mix(0.5, 1.0, sh);
    col += metal * F * amb * 3.0;                                 // metal still picks up the room light

    col += vec3(1.0, 0.55, 0.2) * uGlow * 0.25;                   // struck bar lights up a little

    if (uMat == 4) col *= exp(-dot(vWorld.xz, vWorld.xz) * 3.0);  // table fades into the dark

    gl_FragColor = vec4(pow(aces(col), vec3(1.0 / 2.2)), 1.0);
}
)";

static GLuint compile(GLenum type, const char* src) {
    GLuint s = pCreateShader(type);
    pShaderSource(s, 1, &src, nullptr);
    pCompileShader(s);
    GLint ok = 0;
    pGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[4096];
        pGetShaderInfoLog(s, sizeof log, nullptr, log);
        std::fprintf(stderr, "shader error:\n%s\n", log);
    }
    return s;
}

struct Prog {
    GLuint id = 0;
    GLint uModel, uVP, uLightVP, uBend, uBarLen, uMat, uColor, uCam, uLightDir, uShadow, uShadowOn, uGlow;
};

static Prog makeProgram(const char* vs, const char* fs) {
    Prog p;
    p.id = pCreateProgram();
    pAttachShader(p.id, compile(GL_VERTEX_SHADER, vs));
    pAttachShader(p.id, compile(GL_FRAGMENT_SHADER, fs));
    pLinkProgram(p.id);
    GLint ok = 0;
    pGetProgramiv(p.id, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[4096];
        pGetProgramInfoLog(p.id, sizeof log, nullptr, log);
        std::fprintf(stderr, "link error:\n%s\n", log);
        p.id = 0;
        return p;
    }
    auto U = [&](const char* n) { return pGetUniformLocation(p.id, n); };
    p.uModel = U("uModel"); p.uVP = U("uVP"); p.uLightVP = U("uLightVP");
    p.uBend = U("uBend"); p.uBarLen = U("uBarLen"); p.uMat = U("uMat"); p.uColor = U("uColor");
    p.uCam = U("uCam"); p.uLightDir = U("uLightDir"); p.uShadow = U("uShadow");
    p.uShadowOn = U("uShadowOn"); p.uGlow = U("uGlow");
    return p;
}

// ---------------------------------------------------------------- sound: modal synthesis
static const int SR = 48000;
static const double BASE_FREQ = 1046.502;  // C6, the lowest plate

struct NoteEvent { int semi; float vel; float pan; };
static NoteEvent eventQueue[64];
static std::atomic<int> qHead{0}, qTail{0};  // single producer (UI thread), single consumer (audio)

static void pushNote(int semi, float vel, float pan) {
    int h = qHead.load(std::memory_order_relaxed), n = (h + 1) % 64;
    if (n == qTail.load(std::memory_order_acquire)) return;  // queue full: drop
    eventQueue[h] = {semi, vel, pan};
    qHead.store(n, std::memory_order_release);
}

struct Partial { float phase, inc, amp, decay; };
struct Voice {
    bool on = false;
    Partial p[4];
    int np = 0;
    float click = 0, clickDecay = 0, lp = 0, gainL = 0, gainR = 0, age = 0;
};
static Voice voices[32];
static unsigned rng = 22222;
static float noise01() { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return (rng & 0xffffff) / 16777216.0f; }

static void startVoice(const NoteEvent& e) {
    Voice* v = &voices[0];
    for (auto& c : voices) {  // a free voice, otherwise the quietest one
        if (!c.on) { v = &c; break; }
        if (c.p[0].amp < v->p[0].amp) v = &c;
    }
    double f = BASE_FREQ * std::pow(2.0, e.semi / 12.0);
    // A plain rectangular metal plate (not undercut like concert bars): its bending modes sit at the
    // free-free beam ratios 1 : 2.756 : 5.404 : 8.933, which gives the bell-like toy sound.
    const float ratio[4] = {1.0f, 2.756f, 5.404f, 8.933f};
    const float amp[4] = {1.0f, 0.35f, 0.16f, 0.07f};
    float tau1 = 1.3f * (float)std::pow(BASE_FREQ / f, 0.5);  // seconds; metal rings much longer than wood
    v->np = 0;
    for (int k = 0; k < 4; k++) {
        double fk = f * ratio[k];
        if (fk > SR * 0.45) break;
        float tau = tau1 / std::pow(ratio[k], 1.1f);
        float bright = (k == 0) ? 1.0f : std::pow(e.vel, 1.5f);  // harder stroke = brighter tone
        v->p[v->np++] = {0.0f, (float)(fk / SR), amp[k] * e.vel * bright, std::exp(-1.0f / (tau * SR))};
    }
    v->click = 0.3f * e.vel * e.vel;
    v->clickDecay = std::exp(-1.0f / (0.004f * SR));
    v->lp = 0;
    float pan = std::max(-1.0f, std::min(1.0f, e.pan)) * 0.6f;
    v->gainL = std::sqrt(0.5f * (1 - pan));
    v->gainR = std::sqrt(0.5f * (1 + pan));
    v->age = 0;
    v->on = true;
}

static void audioCallback(ma_device*, void* out, const void*, ma_uint32 frames) {
    while (qTail.load(std::memory_order_relaxed) != qHead.load(std::memory_order_acquire)) {
        int t = qTail.load(std::memory_order_relaxed);
        startVoice(eventQueue[t]);
        qTail.store((t + 1) % 64, std::memory_order_release);
    }
    float* o = (float*)out;
    for (ma_uint32 i = 0; i < frames; i++) {
        float L = 0, R = 0;
        for (auto& v : voices) {
            if (!v.on) continue;
            float s = 0;
            for (int k = 0; k < v.np; k++) {
                Partial& p = v.p[k];
                s += p.amp * std::sin(2 * PI * p.phase);
                p.phase += p.inc;
                if (p.phase >= 1) p.phase -= 1;
                p.amp *= p.decay;
            }
            // mallet contact noise, low-passed
            v.lp += 0.35f * ((noise01() * 2 - 1) * v.click - v.lp);
            v.click *= v.clickDecay;
            s += v.lp;
            float attack = std::min(1.0f, v.age / 24.0f);  // 0.5 ms fade-in, avoids a hard edge
            v.age += 1;
            s *= attack;
            L += s * v.gainL;
            R += s * v.gainR;
            if (v.p[0].amp < 1e-4f && v.click < 1e-4f) v.on = false;
        }
        o[2 * i] = std::tanh(L * 0.45f);
        o[2 * i + 1] = std::tanh(R * 0.45f);
    }
}

// ---------------------------------------------------------------- the instrument
// A children's xylophone: 10 enamelled metal plates on two converging pine rails between two end
// blocks, each plate held by two dome-headed screws at its vibration nodes.
static const int NUM_BARS = 10;                          // C6 .. E7, white notes
static const int SEMIS[NUM_BARS] = {0, 2, 4, 5, 7, 9, 11, 12, 14, 16};
static const float BAR_W = 0.030f, BAR_H = 0.005f, PITCH = 0.038f;
static const float LEN0 = 0.12f;                         // length of the lowest plate
static const float NODE = 0.5f - 0.224f;                 // node of the first mode, measured from the plate centre
static const float RAIL_TOP = 0.042f, RAIL_H = 0.016f, RAIL_W = 0.016f;
static const float BLOCK_W = 0.030f, BLOCK_H = 0.056f;
static const float HEAD_R = 0.011f;

struct Bar {
    int semi;
    double freq;
    float x, z, len, yc;
    float hitTime = -100, hitVel = 0;
    V3 color;
    Mesh mesh;
};
static std::vector<Bar> bars;

static float barX(int i) { return (i - (NUM_BARS - 1) * 0.5f) * PITCH; }
static float frameMinX() { return barX(0) - PITCH * 0.5f - BLOCK_W * 0.5f; }
static float frameMaxX() { return barX(NUM_BARS - 1) + PITCH * 0.5f + BLOCK_W * 0.5f; }

static void buildBars() {
    // the usual toy-xylophone rainbow, one colour per note name: C blue, D green, E yellow, ...
    const V3 PAINT[7] = {
        {0.10f, 0.22f, 0.78f}, {0.16f, 0.66f, 0.22f}, {0.98f, 0.80f, 0.06f}, {0.96f, 0.42f, 0.08f},
        {0.86f, 0.08f, 0.08f}, {0.62f, 0.12f, 0.66f}, {0.93f, 0.93f, 0.95f},
    };
    for (int i = 0; i < NUM_BARS; i++) {
        Bar b;
        b.semi = SEMIS[i];
        b.freq = BASE_FREQ * std::pow(2.0, b.semi / 12.0);
        // for a uniform bar f ~ 1/L^2, so L ~ 1/sqrt(f): the plates get shorter towards the treble
        b.len = LEN0 * (float)std::sqrt(BASE_FREQ / b.freq);
        b.x = barX(i);
        b.z = 0;
        b.yc = RAIL_TOP + BAR_H / 2;
        b.color = PAINT[i % 7];
        b.mesh = makeBox(BAR_W / 2, BAR_H / 2, b.len / 2, 24);
        bars.push_back(b);
    }
}

static const char* NOTE_NAMES[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
static std::string noteName(int semi) { return std::string(NOTE_NAMES[semi % 12]) + std::to_string(6 + semi / 12); }

// ---------------------------------------------------------------- mallets
struct Mallet {
    V3 head;        // where the head is when it touches the plate
    float t = 10;   // seconds since the last stroke
    float side;     // -1 left hand, +1 right hand
};
static Mallet mallets[2];
static const float LIFT = 0.05f;

static V3 strikePoint(const Bar& b) { return {b.x, b.yc + BAR_H / 2 + HEAD_R, b.z}; }

static double now = 0;
static std::string lastNote = "-";

static void strike(int barIndex, float vel) {
    Bar& b = bars[barIndex];
    b.hitTime = (float)now;
    b.hitVel = vel;
    pushNote(b.semi, vel, b.x / 0.2f);
    lastNote = noteName(b.semi);

    V3 target = strikePoint(b);
    // use the closer mallet, but alternate if that one has only just struck (fast repeats / trills)
    int m = std::fabs(mallets[0].head.x - target.x) <= std::fabs(mallets[1].head.x - target.x) ? 0 : 1;
    if (mallets[m].t < 0.06f && mallets[1 - m].t > 0.06f) m = 1 - m;
    mallets[m].head = target;
    mallets[m].t = 0;
}

// ---------------------------------------------------------------- input
struct KeyMap { int key, bar; };
static const KeyMap KEYS[] = {
    {GLFW_KEY_1, 0}, {GLFW_KEY_2, 1}, {GLFW_KEY_3, 2}, {GLFW_KEY_4, 3}, {GLFW_KEY_5, 4},
    {GLFW_KEY_6, 5}, {GLFW_KEY_7, 6}, {GLFW_KEY_8, 7}, {GLFW_KEY_9, 8}, {GLFW_KEY_0, 9},
    {GLFW_KEY_A, 0}, {GLFW_KEY_S, 1}, {GLFW_KEY_D, 2}, {GLFW_KEY_F, 3}, {GLFW_KEY_G, 4},
    {GLFW_KEY_H, 5}, {GLFW_KEY_J, 6}, {GLFW_KEY_K, 7}, {GLFW_KEY_L, 8}, {GLFW_KEY_SEMICOLON, 9},
};

static float camYaw = 0.0f, camPitch = 0.80f, camDist = 0.62f;
static const V3 CAM_TARGET = {0.0f, 0.02f, 0.01f};
static const float FOV = 40.0f * PI / 180.0f;
static bool dragging = false, showShadows = true, bending = true;
static double lastX = 0, lastY = 0;

static V3 cameraEye() {
    return CAM_TARGET + V3{std::cos(camPitch) * std::sin(camYaw), std::sin(camPitch),
                           std::cos(camPitch) * std::cos(camYaw)} * camDist;
}

static void onKey(GLFWwindow* w, int key, int, int action, int mods) {
    if (action != GLFW_PRESS) return;
    if (key == GLFW_KEY_ESCAPE) glfwSetWindowShouldClose(w, 1);
    if (key == GLFW_KEY_F1) showShadows = !showShadows;
    if (key == GLFW_KEY_F2) bending = !bending;
    float vel = (mods & GLFW_MOD_SHIFT) ? 0.45f : 0.85f + 0.15f * noise01();
    for (const KeyMap& k : KEYS)
        if (k.key == key) { strike(k.bar, vel); break; }
}

// Ray picking: a ray from the eye through the mouse position, tested against every plate's box.
static int pickBar(GLFWwindow* w, double mx, double my) {
    int ww, wh;
    glfwGetWindowSize(w, &ww, &wh);
    float nx = (float)(2 * mx / ww - 1), ny = (float)(1 - 2 * my / wh);
    V3 eye = cameraEye(), f = norm(CAM_TARGET - eye), r = norm(cross(f, {0, 1, 0})), u = cross(r, f);
    float th = std::tan(FOV / 2);
    V3 d = norm(f + r * (nx * th * ww / (float)wh) + u * (ny * th));
    int best = -1;
    float bestT = 1e9f;
    for (int i = 0; i < NUM_BARS; i++) {
        const Bar& b = bars[i];
        V3 lo = {b.x - BAR_W / 2, b.yc - BAR_H / 2, b.z - b.len / 2};
        V3 hi = {b.x + BAR_W / 2, b.yc + BAR_H / 2, b.z + b.len / 2};
        float t0 = 0, t1 = 1e9f;
        const float o[3] = {eye.x, eye.y, eye.z}, dd[3] = {d.x, d.y, d.z};
        const float l[3] = {lo.x, lo.y, lo.z}, h[3] = {hi.x, hi.y, hi.z};
        bool hit = true;
        for (int a = 0; a < 3 && hit; a++) {  // slab test
            if (std::fabs(dd[a]) < 1e-8f) { if (o[a] < l[a] || o[a] > h[a]) hit = false; continue; }
            float ta = (l[a] - o[a]) / dd[a], tb = (h[a] - o[a]) / dd[a];
            if (ta > tb) std::swap(ta, tb);
            t0 = std::max(t0, ta);
            t1 = std::min(t1, tb);
            if (t0 > t1) hit = false;
        }
        if (hit && t0 < bestT) { bestT = t0; best = i; }
    }
    return best;
}

static void onMouseButton(GLFWwindow* w, int button, int action, int) {
    if (button != GLFW_MOUSE_BUTTON_LEFT) return;
    if (action == GLFW_PRESS) {
        glfwGetCursorPos(w, &lastX, &lastY);
        int b = pickBar(w, lastX, lastY);
        if (b >= 0) strike(b, 0.85f);
        else dragging = true;
    } else {
        dragging = false;
    }
}

static void onCursor(GLFWwindow*, double x, double y) {
    if (dragging) {
        camYaw -= (float)(x - lastX) * 0.008f;
        camPitch = std::max(0.05f, std::min(1.45f, camPitch + (float)(y - lastY) * 0.006f));
    }
    lastX = x;
    lastY = y;
}

static void onScroll(GLFWwindow*, double, double dy) {
    camDist = std::max(0.2f, std::min(1.8f, camDist * std::pow(0.9f, (float)dy)));
}

// ---------------------------------------------------------------- drawing
static Prog mainProg, depthProg;
static Prog* cur = nullptr;
static bool shadowPass = false;
static Mesh unitBox, rod, sphere;

static void draw(const Mesh& m, const M4& model, int mat, V3 col, float bend = 0, float barLen = 0, float glow = 0) {
    if (shadowPass && mat == 4) return;  // the table doesn't cast shadows
    pUniformMatrix4fv(cur->uModel, 1, GL_FALSE, model.m);
    pUniform1f(cur->uBend, bend);
    pUniform1f(cur->uBarLen, barLen);
    if (!shadowPass) {
        pUniform1i(cur->uMat, mat);
        pUniform3f(cur->uColor, col.x, col.y, col.z);
        pUniform1f(cur->uGlow, glow);
    }
    m.draw();
}

// unit box stretched from a to b (a horizontal-ish beam), h tall and w wide
static void beam(V3 a, V3 b, float h, float w, int mat, V3 col) {
    V3 X = b - a, Z = norm(cross(X, {0, 1, 0})), Y = norm(cross(Z, X));
    draw(unitBox, basis(X, Y * h, Z * w, (a + b) * 0.5f), mat, col);
}
// cylinder of radius r from a to b
static void rodBetween(const Mesh& m, V3 a, V3 b, float r, int mat, V3 col) {
    V3 Y = b - a, helper = std::fabs(Y.y) > 0.9f * length(Y) ? V3{1, 0, 0} : V3{0, 1, 0};
    V3 X = norm(cross(Y, helper)), Z = norm(cross(X, Y));
    draw(m, basis(X * r, Y, Z * r, a), mat, col);
}

static const V3 PINE = {0.90f, 0.76f, 0.56f};
static const V3 STEEL = {0.82f, 0.82f, 0.84f};

static void drawFrame() {
    float z0 = NODE * bars.front().len, z1 = NODE * bars.back().len;  // rail offsets at both ends
    float x0 = frameMinX(), x1 = frameMaxX();
    // two rails under the node lines; they converge because the plates get shorter
    for (int side = -1; side <= 1; side += 2)
        beam({x0, RAIL_TOP - RAIL_H / 2, side * z0}, {x1, RAIL_TOP - RAIL_H / 2, side * z1}, RAIL_H, RAIL_W, 3, PINE);
    // end blocks
    float l0 = 2 * z0 + RAIL_W + 0.03f, l1 = 2 * z1 + RAIL_W + 0.03f;
    beam({x0, BLOCK_H / 2, -l0 / 2}, {x0, BLOCK_H / 2, l0 / 2}, BLOCK_H, BLOCK_W, 3, PINE);
    beam({x1, BLOCK_H / 2, -l1 / 2}, {x1, BLOCK_H / 2, l1 / 2}, BLOCK_H, BLOCK_W, 3, PINE);
}

static void drawPlates() {
    for (const Bar& b : bars) {
        float dt = (float)now - b.hitTime;
        float env = dt >= 0 ? std::exp(-dt * 4.0f) : 0;
        float bend = bending ? 0.003f * b.hitVel * env * std::sin(2 * PI * 13.0f * dt) : 0;
        float glow = dt >= 0 ? b.hitVel * std::exp(-dt * 7.0f) : 0;
        draw(b.mesh, translate({b.x, b.yc, b.z}), 6, b.color, bend, b.len, glow);

        // two dome-headed screws through the plate at its nodes (they don't move: nodes stay still)
        float top = b.yc + BAR_H / 2;
        for (int side = -1; side <= 1; side += 2) {
            float z = b.z + side * NODE * b.len;
            draw(rod, trs({b.x, RAIL_TOP - 0.006f, z}, {0.0016f, top - RAIL_TOP + 0.009f, 0.0016f}), 1, STEEL);
            draw(sphere, trs({b.x, top + 0.0035f, z}, {0.0036f, 0.0026f, 0.0036f}), 1, STEEL);
        }
    }
}

static void drawMallets() {
    for (Mallet& m : mallets) {
        float lift = LIFT * (1 - std::exp(-m.t * 16.0f));  // touches the plate at t = 0, then bounces up
        V3 head = m.head + V3{0, lift, 0};
        V3 hand = head + V3{0.04f * m.side, 0.07f, 0.19f};
        rodBetween(rod, head, hand, 0.003f, 3, PINE);
        draw(sphere, trs(head, {HEAD_R, HEAD_R, HEAD_R}), 2, {0.62f, 0.07f, 0.05f});
    }
}

static void drawScene() {
    drawFrame();
    drawPlates();
    drawMallets();
}

static void saveScreenshot(const char* path, int w, int h) {
    std::vector<unsigned char> px(w * h * 3);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, px.data());
    FILE* f = std::fopen(path, "wb");
    if (!f) return;
    std::fprintf(f, "P6\n%d %d\n255\n", w, h);
    for (int y = h - 1; y >= 0; y--) std::fwrite(&px[y * w * 3], 1, w * 3, f);
    std::fclose(f);
}

// ---------------------------------------------------------------- main
int main() {
    if (!glfwInit()) { std::fprintf(stderr, "GLFW init failed\n"); return 1; }
    glfwWindowHint(GLFW_SAMPLES, 4);
    GLFWwindow* win = glfwCreateWindow(1280, 760, "Xylophone", nullptr, nullptr);
    if (!win) { std::fprintf(stderr, "Could not open a window\n"); glfwTerminate(); return 1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);

    bool haveFbo = false;
    if (!loadGL(haveFbo)) {
        std::fprintf(stderr, "This program needs OpenGL 2.0 shaders.\n");
        return 1;
    }
    mainProg = makeProgram(VS_SRC, FS_SRC);
    depthProg = makeProgram(VS_SRC, DEPTH_FS_SRC);
    if (!mainProg.id) return 1;

    // shadow map: a depth texture attached to a framebuffer
    const int SHADOW_SIZE = 2048;
    GLuint shadowTex = 0, shadowFbo = 0;
    if (haveFbo && depthProg.id) {
        glGenTextures(1, &shadowTex);
        glBindTexture(GL_TEXTURE_2D, shadowTex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, SHADOW_SIZE, SHADOW_SIZE, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        pGenFramebuffers(1, &shadowFbo);
        pBindFramebuffer(GL_FRAMEBUFFER, shadowFbo);
        pFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex, 0);
        glDrawBuffer(GL_NONE);
        glReadBuffer(GL_NONE);
        if (pCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) shadowFbo = 0;
        pBindFramebuffer(GL_FRAMEBUFFER, 0);
        glDrawBuffer(GL_BACK);
        glReadBuffer(GL_BACK);
    }
    if (!shadowFbo) { showShadows = false; std::printf("Shadows unavailable on this GPU.\n"); }

    glfwSetKeyCallback(win, onKey);
    glfwSetMouseButtonCallback(win, onMouseButton);
    glfwSetCursorPosCallback(win, onCursor);
    glfwSetScrollCallback(win, onScroll);

    // geometry
    buildBars();
    unitBox = makeBox(0.5f, 0.5f, 0.5f, 1);
    rod = makeCylinder(12, true, true);
    sphere = makeSphere(24, 16);
    mallets[0] = {strikePoint(bars[2]), 10, -1};   // left hand over E6
    mallets[1] = {strikePoint(bars[7]), 10, 1};    // right hand over C7

    // audio
    ma_device device;
    ma_device_config cfg = ma_device_config_init(ma_device_type_playback);
    cfg.playback.format = ma_format_f32;
    cfg.playback.channels = 2;
    cfg.sampleRate = SR;
    cfg.dataCallback = audioCallback;
    bool audioOk = ma_device_init(nullptr, &cfg, &device) == MA_SUCCESS && ma_device_start(&device) == MA_SUCCESS;
    if (!audioOk) std::printf("No audio device - running silently.\n");

    std::printf(
        "Xylophone - 10 plates, C6-E7\n"
        "  1 2 3 4 5 6 7 8 9 0   or   A S D F G H J K L ;\n"
        "  Shift = soft  |  click a plate = strike  |  drag = orbit, scroll = zoom\n"
        "  F1 shadows  |  F2 plate bending  |  Esc quit\n");

    const char* shotPath = std::getenv("XYLO_SHOT");  // for screenshots in the documentation
    const char* shotYaw = std::getenv("XYLO_YAW");
    if (shotYaw) camYaw = (float)std::atof(shotYaw);
    int frame = 0;

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);

    V3 lightDir = norm({-0.45f, 1.0f, 0.55f});
    M4 lightVP = mul(ortho(-0.4f, 0.4f, -0.4f, 0.4f, 0.2f, 3.0f),
                     lookAt(V3{0, 0.03f, 0} + lightDir * 1.5f, {0, 0.03f, 0}, {0, 1, 0}));
    double prev = glfwGetTime();
    std::string shownTitle;

    while (!glfwWindowShouldClose(win)) {
        now = glfwGetTime();
        float dt = (float)(now - prev);
        prev = now;
        if (shotPath) {  // scripted strokes for the screenshot
            now = frame / 60.0;
            dt = 1 / 60.0f;
            if (frame == 40) strike(4, 1.0f);
            if (frame == 44) strike(8, 1.0f);
        }
        for (Mallet& m : mallets) m.t += dt;

        // pass 1: depth from the light
        if (showShadows && shadowFbo) {
            glBindTexture(GL_TEXTURE_2D, 0);
            pBindFramebuffer(GL_FRAMEBUFFER, shadowFbo);
            glViewport(0, 0, SHADOW_SIZE, SHADOW_SIZE);
            glClear(GL_DEPTH_BUFFER_BIT);
            cur = &depthProg;
            pUseProgram(cur->id);
            pUniformMatrix4fv(cur->uVP, 1, GL_FALSE, lightVP.m);
            shadowPass = true;
            drawScene();
            shadowPass = false;
            pBindFramebuffer(GL_FRAMEBUFFER, 0);
        }

        // pass 2: the camera view
        int fw, fh;
        glfwGetFramebufferSize(win, &fw, &fh);
        glViewport(0, 0, fw, fh);
        glClearColor(0.10f, 0.10f, 0.11f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        V3 eye = cameraEye();
        M4 vp = mul(perspective(FOV, fh > 0 ? (float)fw / fh : 1.0f, 0.01f, 10.0f), lookAt(eye, CAM_TARGET, {0, 1, 0}));
        cur = &mainProg;
        pUseProgram(cur->id);
        pUniformMatrix4fv(cur->uVP, 1, GL_FALSE, vp.m);
        pUniformMatrix4fv(cur->uLightVP, 1, GL_FALSE, lightVP.m);
        pUniform3f(cur->uCam, eye.x, eye.y, eye.z);
        pUniform3f(cur->uLightDir, lightDir.x, lightDir.y, lightDir.z);
        pUniform1f(cur->uShadowOn, (showShadows && shadowFbo) ? 1.0f : 0.0f);
        pUniform1i(cur->uShadow, 1);
        pActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, shadowTex);
        pActiveTexture(GL_TEXTURE0);
        drawScene();

        std::string title = "Xylophone  |  " + lastNote + "  |  shadows " + (showShadows ? "on" : "off") +
                            "  |  bending " + (bending ? "on" : "off");
        if (title != shownTitle) { glfwSetWindowTitle(win, title.c_str()); shownTitle = title; }

        if (shotPath && frame == 47) { saveScreenshot(shotPath, fw, fh); break; }
        glfwSwapBuffers(win);
        glfwPollEvents();
        frame++;
    }

    if (audioOk) ma_device_uninit(&device);
    glfwTerminate();
    return 0;
}
